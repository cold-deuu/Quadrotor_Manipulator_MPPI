^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_rotors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2018-12-13)
------------------

2.2.2 (2018-12-12)
------------------

2.2.0 (2018-12-10)
------------------
* switch to package format 2
* Merge pull request `#411 <https://github.com/ethz-asl/rotors_simulator/issues/411>`_ from ethz-asl/fix/hil_gui_element_access
  Fixing GUI element access in rqt_rotors
* Fixing GUI element access in rqt_rotors
* Merge pull request `#397 <https://github.com/ethz-asl/rotors_simulator/issues/397>`_ from ethz-asl/v2.1.1
  update to 2.1.1
* Merge pull request `#398 <https://github.com/ethz-asl/rotors_simulator/issues/398>`_ from ethz-asl/fix/rqt_rotors
  Skip RQT rotors if mavros not found.
* Skip RQT rotors if mavros not found.
* Contributors: Fadri Furrer, Helen Oleynikova, Mina Kamel, Pavel Vechersky, pvechersky

2.1.1 (2017-04-27)
-----------
* Update maintainers.
* Contributors: Timo Hinzmann
